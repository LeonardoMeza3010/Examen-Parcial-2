
package conexion_usuarios;

import java.sql.*;

public class ConexionUsuarios {
    private Connection con;
    private Statement stmt;

    public ConexionUsuarios(String urlBD, String usuarioBD, String passwordBD) throws SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection ("jdbc:mysql://localhost/bdasimeza","leo10","asi123");
            stmt = con.createStatement();
        } catch (ClassNotFoundException e) {
            // Manejar la excepción de clase no encontrada
            e.printStackTrace();
            throw new SQLException("Error al cargar el controlador de base de datos.");
        }
    }

    public int ejecutaSentencia(String sql, Object... params) throws SQLException {
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }
            return pstmt.executeUpdate();
        }
    }

    public void cerrar() {
        try {
            if (stmt != null) stmt.close();
            if (con != null) con.close();
        } catch (SQLException e) {
            // Manejar la excepción de cierre de recursos
            e.printStackTrace();
        }
    }
}