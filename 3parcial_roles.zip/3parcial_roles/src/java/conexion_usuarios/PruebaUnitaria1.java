package conexion_usuarios;


public class PruebaUnitaria1 {

    public static void main(String[] args) {
        long startTime=System.currentTimeMillis();
        String srtPruebaUnitaria=" JAVA WEB JSP Multiplataforma prueba desde JVM, JDK, JRE";
        String tmpString=" ";
        
        int numInteracciones=5000;
        for (int i=0;i<numInteracciones;i++){
            tmpString= tmpString+srtPruebaUnitaria;
        }
        
        System.out.println("Inicial : "+tmpString);
        long endTime=System.currentTimeMillis()-startTime;
        System.err.println("Tiempo Final de prueba Unitaria: "+endTime);
}
}