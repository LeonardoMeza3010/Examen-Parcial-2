package conexion_usuarios;

/**
 *
 * @author PC-4
 */
public class PruebaUnitaria2 {
 
    public static void main(String[] args) {
        long startTime=System.currentTimeMillis();
        String srtPruebaUnitaria="\nJAVA WEB JSP Multiplataforma prueba desde JVM, JDK, JRE";
        String tmpString=" ";        
        
        StringBuilder strBuilder=new StringBuilder();
        int numInteracciones=5000;
        
        for (int i=0;i<numInteracciones;i++){
            strBuilder.append(srtPruebaUnitaria);
        }        
        
        System.out.println(strBuilder.toString());
        long endTime=System.currentTimeMillis()-startTime;
        System.out.println("\nTiempo de Pruba Unitaria 2 :"+endTime);
        
    }
}